import java.util.Scanner;
public class Task2{
public static void main(String[] args) {
int[] arr = new int[10];
int sum = 0;
Scanner scanner = new Scanner(System.in);
for (int i = 0; i < 10; i++) {
arr[i] = scanner.nextInt();
}
for (int num : arr) {
if (num % 4 == 0) {
sum += num;
}
}
System.out.println("Sum of multiples of 4: " + sum);
scanner.close();
}
}
