import java.util.Scanner;
public class Task4{
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
String[] names = new String[6];
for (int i = 0; i < 6; i++) {
names[i] = scanner.nextLine();
}
boolean found = false;
for (String name : names) {
if (name.toLowerCase().equals("ali")) { 
found = true;
break;
}
}
System.out.println(found ? "Ali is present" : "Ali is not present");
scanner.close();
}
}
