public class Task5{
public static void main(String[] args) {
int[][] matrix = {
      {1, 1, 0, 0, 1},
      {1, 0, 1, 0, 1},
      {1, 0, 0, 1, 1},
      {1, 0, 0, 0, 1}
};
 if (containsN(matrix)) {
System.out.println("The matrix contains the letter 'N'.");
} else {
System.out.println("The matrix does not contain the letter 'N'.");
}
}
public static boolean containsN(int[][] matrix) {
return matrix[0][0] == 1 && matrix[0][1] ==1 && matrix[0][4] == 1 &&
matrix[1][0] == 1 && matrix[1][2] == 1 && matrix[1][4] == 1 &&
matrix[2][0] == 1 && matrix[2][4] == 1 &&
matrix[3][0] == 1 && matrix[3][4] == 1;
}
}
