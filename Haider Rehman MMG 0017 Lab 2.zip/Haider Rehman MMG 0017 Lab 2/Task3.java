import java.util.Scanner;
public class Task3 {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
System.out.print("Input number of rows of matrix: ");
int rows = scanner.nextInt();
System.out.print("Input number of columns of matrix: ");
int cols = scanner.nextInt();
int[][] matrix1 = new int[rows][cols];
int[][] matrix2 = new int[rows][cols];
int[][] sumMatrix = new int[rows][cols];
System.out.println("Enter values for the first matrix: ");
for (int i = 0; i < rows; i++) {
for (int j = 0; j < cols; j++) {
System.out.print("Enter element at matrix1[" + i + "][" + j + "]: ");
matrix1[i][j] = scanner.nextInt();
}
}
System.out.println("Enter values for the second matrix: ");
for (int i = 0; i < rows; i++) {
for (int j = 0; j < cols; j++) {
System.out.print("Enter element at matrix2[" + i + "][" + j + "]: ");
matrix2[i][j] = scanner.nextInt();
}
}
for (int i = 0; i < rows; i++) {
for (int j = 0; j < cols; j++) {
sumMatrix[i][j] = matrix1[i][j] + matrix2[i][j];
}
}
System.out.println("Sum of the matrices: ");
for (int i = 0; i < rows; i++) {
for (int j = 0; j < cols; j++) {
System.out.print(sumMatrix[i][j] + " ");
}
System.out.println();
}
scanner.close();
}
}
