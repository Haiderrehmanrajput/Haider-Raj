class Book {
    String title;
    String author;
    boolean isAvailable;

    Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    void borrowBook() {
        if (isAvailable) {
            System.out.println("The book \"" + title + "\" is available.");
            isAvailable = false;
        } else {
            System.out.println("The book \"" + title + "\" is not available.");
        }
    }

    void returnBook() {
        isAvailable = true;
        System.out.println("The book \"" + title + "\" has been returned and is now available.");
    }

    void displayBookDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Available: " + (isAvailable ? "Yes" : "No"));
    }

    public static void main(String[] args) {
        Book b1 = new Book("Daffodils", "William Wordsworth");
        b1.displayBookDetails();
        b1.borrowBook();
        System.out.println("--------");
        b1.displayBookDetails();
        b1.returnBook();
        System.out.println("--------");
        b1.displayBookDetails();
    }
}
