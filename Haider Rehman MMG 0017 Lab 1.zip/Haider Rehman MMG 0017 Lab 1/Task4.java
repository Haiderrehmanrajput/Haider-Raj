class Task4{
public static void main(String[] ags){
int result = (10 + 5) * (4 - 6) / 4;
System.out.println("The result of the mathematical expression (10 + 5) * (4 - 6) / 4 is: " + result);
}
}