class Task3 {
public static void main(String[] args) {
String name = "Haider";
float age = 19;
float GPA = 3.85f; 
char gender = 'M';
String Foreigner = "no";
String StudentId = "83893";

System.out.println("Name: " + name);
System.out.println("Age: " + age);
System.out.println("GPA: " + GPA); 
System.out.println("Gender: " + gender);
System.out.println("Foreigner: " + Foreigner);
System.out.println("Student ID: " + StudentId);
}
}
